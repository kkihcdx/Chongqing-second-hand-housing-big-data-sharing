package com.swu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectdesignApplicationTests {

    @Test
    void contextLoads() {
    }

}
