package com.swu;

import com.swu.dao.db1.MysqlMapper;
import com.swu.dao.db2.HiveMapper;
import com.swu.entity.User;
import com.swu.entity.house;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MysqlTest {

    @Resource
    MysqlMapper mysqlMapper;
    @Resource
    HiveMapper hiveMapper;

//    @Test
//    public void Test(){
//        house a=hiveMapper.selectList();
//        System.out.println(a);
//    }

    @Test
    public void Test2(){
        List<User> b=mysqlMapper.getUserByName();
        for (User user:b) {
            System.out.println(user);
        }
    }
//    @Autowired
//    private com.swu.dao.HiveJdbcBaseDaoImpl hiveJdbcBaseDaoImpl;
//
//    @Autowired
//    private MysqlMainJdbcBaseDaoImpl MysqlMainJdbcBaseDaoImpl;


//    @Test
//    public void testMysql() {
////        String sql = "SELECT name from house limit 1";
////        String info = hiveJdbcBaseDaoImpl.getJdbcTemplate().queryForObject(sql,String.class);
////       System.out.println("hive中查出的数据是："+info);
//
//        //校验该表是否在数据库中存在
//        String sql1 = "SELECT  count(*) FROM users ";
//        int count = MysqlMainJdbcBaseDaoImpl.getJdbcTemplate().queryForObject(sql1, Integer.class);
//        System.out.println("mysql中查出的数据是："+count);
//    }
}
