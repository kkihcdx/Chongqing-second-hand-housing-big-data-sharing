package com.swu;

import com.swu.dao.db2.HiveMapper;
import org.apache.hive.service.cli.CLIService;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest
public class HiveApi {

    @Resource
    private HiveMapper hiveMapper;

//    @Test
//    public void hiveTest(){
//        SqlSession sqlSession = sessionFactory.openSession();
//        List<areaData> b=hiveMapper.houseList();
//        for (areaData data:b) {
//            System.out.println(data);
//        }
//    }


//
//    @Autowired
//    private HiveJdbcBaseDaoImpl hiveDao;
//
//    @Test
//    void hiveTest() {
//        List<Map<String, Object>> hiveMaps = hiveDao.select();
//        for (Map<String, Object> hiveMap : hiveMaps) {
//            System.out.println(hiveMap);
//        }
//    }
}
