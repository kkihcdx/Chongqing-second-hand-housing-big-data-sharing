package com.swu.controller;

import com.swu.dao.db2.HiveMapper;
import com.swu.entity.houseData;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/test")
public class helloController {

    @Resource
    private HiveMapper hiveMapper;

//    @GetMapping("/UserList")
//    @ResponseBody
//    public List<house> queryUserList(){
//        List<house> houseList = hiveMapper.selectListbySum(10);
//        for (house h:houseList) {
//            System.out.println(h);
//        }
//        return houseList;
//    }
    @RequestMapping("/cyt")
    @ResponseBody
    public String getcyt() throws JsonProcessingException {
        List<houseData> dataList=hiveMapper.cyt();
//        List<houseData> dataList=new ArrayList<>();
//        dataList.add(new houseData("VR看装修",143314.0));
//        dataList.add(new houseData("地铁",84440.0));
//        dataList.add(new houseData("随时看房",79304.0));
//        dataList.add(new houseData("VR房源",54500.0));
//        dataList.add(new houseData("无",34776.0));
//        dataList.add(new houseData("房本满五年",29468.0));
//        dataList.add(new houseData("房本满两年",27418.0));
        System.out.println(dataList);
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(dataList);
        return json;
    }

    @GetMapping("/cq")
    @ResponseBody
    public String getCq() throws JsonProcessingException {
        List<houseData> dataList=hiveMapper.houseList();
        dataList.add(new houseData("万州区",10.0));
        dataList.add(new houseData("南川区",20.0));
        dataList.add(new houseData("永川区",8.0));
        dataList.add(new houseData("南岸区",1.0));
        dataList.add(new houseData("大足区",3.0));
        dataList.add(new houseData("璧山区",15.0));
        dataList.add(new houseData("梁平区",2.0));
        dataList.add(new houseData("铜梁区",2.0));
        dataList.add(new houseData("潼南区",3.0));
        dataList.add(new houseData("黔江区",2.0));
        dataList.add(new houseData("武隆区",1.0));
        dataList.add(new houseData("城口县",1.0));
        dataList.add(new houseData("丰都县",1.0));
        dataList.add(new houseData("云阳县",1.0));
        dataList.add(new houseData("巫溪县",10.0));
        System.out.println(dataList);
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(dataList);
        return json;
    }

    @GetMapping("/rose")
    @ResponseBody
    public String getfloor() throws JsonProcessingException {
        List<houseData> dataList=hiveMapper.houseList2();
        System.out.println(dataList);
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(dataList);
        return json;
    }

    @GetMapping("/data")
    @ResponseBody
    public String gethouse_type() throws JsonProcessingException {
        List<houseData> dataList=hiveMapper.houseList3();
        System.out.println(dataList);
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(dataList);
        return json;
    }

    @GetMapping("/years")
    @ResponseBody
    public String getyaers() throws JsonProcessingException{
        List<houseData> dataList=hiveMapper.houseList4();
        System.out.println(dataList);
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(dataList);
        return json;
    }
}
