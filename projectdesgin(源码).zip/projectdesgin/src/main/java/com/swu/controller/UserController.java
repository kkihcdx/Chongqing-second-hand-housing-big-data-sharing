package com.swu.controller;

import com.swu.dao.db1.MysqlMapper;
import com.swu.entity.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@Controller
public class UserController {
    @Resource
    private MysqlMapper mysqlMapper;

    @GetMapping("/login")
    @ResponseBody
    public List<User> queryUserList(){
        List<User> userList = mysqlMapper.getUserByName();
        for (User user:userList) {
            System.out.println(user);
        }
        return userList;
    }

    @PostMapping("/vueformModePost")
    @ResponseBody
    //@RequestMapping(value ="/vueformget", method = {RequestMethod.POST})
    public String vueformModePost(User userInfo) {
        System.out.println(userInfo.getName()+userInfo.getPwd());
        User i=mysqlMapper.getUserByNameAndPwd(userInfo.getName(),userInfo.getPwd());
        System.out.println(i);
        if(i!=null){
            return "/test.html";
        }else{
            return "error";
        }
    }

}
