package com.swu.dao.db1;

import com.swu.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface MysqlMapper{
    User selectList();
    List<User> getUserByName();
    User getUserByNameAndPwd(@Param("name")String name,@Param("pwd")String pwd);
}