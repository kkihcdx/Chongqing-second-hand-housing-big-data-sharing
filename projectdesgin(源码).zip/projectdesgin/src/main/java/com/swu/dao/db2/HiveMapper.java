package com.swu.dao.db2;

import com.swu.entity.houseData;
import com.swu.entity.house;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface HiveMapper {

   List<house> selectListbySum(int sum);

   List<houseData> houseList();

   List<houseData> houseList2();

   List<houseData> houseList3();

   List<houseData> houseList4();

   List<houseData> cyt();

}
