package com.swu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectdesignApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjectdesignApplication.class, args);
    }

}
