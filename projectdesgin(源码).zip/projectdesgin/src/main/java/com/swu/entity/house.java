package com.swu.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class house {
    private int id;
    private String name;
    private String location;
    private float total_price;
    private float avg_price;
    private float area;
    private String house_type;
    private String floor;
    private String decoration;
    private String time;
    private String building_type;
}
